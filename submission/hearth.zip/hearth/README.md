# A simple streak builder extension
