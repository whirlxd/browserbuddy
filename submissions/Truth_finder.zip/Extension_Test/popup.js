document.addEventListener('DOMContentLoaded', () => {
    // Update counters when popup opens
    //chrome.storage.local.get(['checksToday', 'factsFound'], (data) => {
     // document.querySelector('.stat-number:first-child').textContent = data.checksToday || 0;
     // document.querySelector('.stat-number:last-child').textContent = data.factsFound || 0;
    //});
  });
  